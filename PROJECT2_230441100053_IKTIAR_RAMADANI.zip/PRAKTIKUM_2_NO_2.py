print("MENENTUKAN NAMA, RATA-RATA, DAN POINT MAHASISWA")

print(" ")

nama = str(input("MASUKKAN NAMA ANDA              : "))
nilai_tugas = float(input("MASUKKAN NILAI TUGAS ANDA       : "))
nilai_uts = float(input("MASUKKAN NILAI UTS ANDA         : "))
nilai_uas = float(input("MASUKKAN NILAI UAS ANDA         : "))
nilai_tugas_akhir = float(input("MASUKKAN NILAI TUGAS AKHIR ANDA : "))

rata_rata = (nilai_tugas + nilai_uts + nilai_uas + nilai_tugas_akhir)/4

if not (0 <= nilai_tugas <= 100):
    print("Nilai salah")
elif not (0 <= nilai_uts <= 100):
    print("Nilai salah")
elif not (0 <= nilai_uas <= 100):
    print("Nilai salah")
elif not (0 <= nilai_tugas_akhir <= 100):
    print("Nilai salah")
else:
    rata_rata

if 80 <= rata_rata <= 100:
    print('nilai A')
elif 70 <= rata_rata < 80:
    print('nilai B')
elif 60 <= rata_rata < 70:
    print('nilai C')
elif 40 <= rata_rata < 60:
    print('nilai D')
elif 0 <= rata_rata < 40:
    print('nilai E')
else:
    print('Nilai Tidak Ditemukan')




