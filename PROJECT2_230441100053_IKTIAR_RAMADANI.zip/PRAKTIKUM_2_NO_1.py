print("===== MENYELEKSI BERDASAR UMUR =====")

user = int(input("MASUKKAN UMUR ANDA : "))

if user >= 50 :
    print("Karena umur anda", user ,"Maka anda dapat dikatakan Tua")
elif user >= 25 :
    print("Karena umur anda", user ,"Maka anda dapat dikatakan Dewasa")
elif user >= 17 :
    print("Karena umur anda", user ,"Maka anda dapat dikatakan Muda")
elif user >= 7 :
    print("Karena umur anda", user ,"Maka anda dapat dikatakan Anak")
else :
    print("bukan salah satu dari jenis diatas")
    # if user >= 6 :
    #     print("Karena umur anda", user ,"Maka anda dapat dikatakan Anak Prasekolah")
    # elif user >=2 :
    #     print("Karena umur anda", user ,"Maka anda dapat dikatakan Balita")
    # else :
    #     print("Karena umur anda", user ,"Maka anda dapat dikatakan Bayi")
















