print("===== PERMAINAN KERTAS GUNTING BATU =====")

print(" ")

usersatu= input("Pemain satu (kertas/gunting/batu):")
userdua= input("Pemain dua (kertas/gunting/batu):")

if usersatu == userdua :
    hasil = "hasil : Seri!!!"
elif usersatu == "kertas" and userdua == "gunting" :
    hasil = "Pemain dua menang"
elif usersatu == "gunting" and userdua == "batu" :
    hasil = "Pemain dua menang"
elif usersatu == "batu" and userdua == "kertas" :
    hasil = "Pemain dua menang"
elif usersatu == "gunting" and userdua == "kertas" :
    hasil = "Pemain satu menang"
elif usersatu == "batu" and userdua == "gunting" :
    hasil = "Pemain satu menang"
elif usersatu == "kertas" and userdua == "batu" :
    hasil = "Pemain satu menang"
else :
    hasil = "Kata salah"

print(" ")

print( hasil )





